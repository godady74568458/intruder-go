package main

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"intruder/engine/pkg/intruder"
	"intruder/engine/pkg/passive"
)

type server struct{}

type requestInput struct {
	Method  string            `json:"method"`
	URL     string            `json:"url"`
	Headers map[string]string `json:"headers"`
	Body    string            `json:"body"`
}

type intruderInput struct {
	BaseRequest  requestInput         `json:"base_request"`
	Mode         intruder.AttackMode  `json:"mode"`
	Payloads     [][]string           `json:"payloads"`
	Dictionaries map[string][]string  `json:"dictionaries"`
	Transforms   []intruder.Transform `json:"transformations"`
}

func main() {
	if err := passive.ConfigureCA(); err != nil {
		log.Fatalf("configure passive proxy CA: %v", err)
	}

	s := &server{}
	mux := http.NewServeMux()
	mux.HandleFunc("/health", s.health)
	mux.HandleFunc("/proxy/request", s.request)
	mux.HandleFunc("/proxy/intruder", s.intruder)
	store := passive.NewStore()
	proxy := passive.NewProxy(store)

	go func() {
		log.Println("passive MITM proxy listening on 127.0.0.1:8080")
		if err := http.ListenAndServe("127.0.0.1:8080", proxy.Handler()); err != nil {
			log.Fatalf("passive proxy: %v", err)
		}
	}()

	log.Println("engine listening on 127.0.0.1:8081")
	log.Fatal(http.ListenAndServe("127.0.0.1:8081", mux))
}

func (s *server) health(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]interface{}{"ok": true})
}

func (s *server) request(w http.ResponseWriter, r *http.Request) {
	var input requestInput
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_JSON", err)
		return
	}
	result, err := s.execute(r, input)
	if err != nil {
		writeError(w, http.StatusBadGateway, "REQUEST_FAILED", err)
		return
	}
	writeJSON(w, http.StatusOK, result)
}

func (s *server) execute(r *http.Request, input requestInput) (map[string]interface{}, error) {
	method := input.Method
	if method == "" {
		method = http.MethodGet
	}
	req, err := http.NewRequestWithContext(r.Context(), method, input.URL, strings.NewReader(input.Body))
	if err != nil {
		return nil, err
	}
	for key, value := range input.Headers {
		req.Header.Set(key, value)
	}
	start := time.Now()
	resp, err := (&http.Client{CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}).Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	headers := map[string]string{}
	for key, values := range resp.Header {
		headers[key] = strings.Join(values, ", ")
	}
	return map[string]interface{}{"status": resp.StatusCode, "time": time.Since(start).Milliseconds(), "size": len(body), "headers": headers, "body": string(body)}, nil
}

func (s *server) intruder(w http.ResponseWriter, r *http.Request) {
	var input intruderInput
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_JSON", err)
		return
	}
	markers := requestPositions(input.BaseRequest)
	payloadSets := make([][]string, len(markers))
	for setIndex := range payloadSets {
		set := []string(nil)
		if values, ok := input.Dictionaries[markers[setIndex]]; ok {
			set = values
		} else if values, ok := input.Dictionaries[strconv.Itoa(setIndex)]; ok {
			set = values
		} else if len(input.Payloads) > 0 {
			payloadIndex := setIndex
			if payloadIndex >= len(input.Payloads) {
				payloadIndex = len(input.Payloads) - 1
			}
			set = input.Payloads[payloadIndex]
		}
		payloadSets[setIndex] = make([]string, len(set))
		for valueIndex, value := range set {
			transformed, transformErr := intruder.TransformPayload(value, input.Transforms)
			if transformErr != nil {
				writeError(w, http.StatusBadRequest, "INVALID_TRANSFORMATION", transformErr)
				return
			}
			payloadSets[setIndex][valueIndex] = transformed
		}
	}
	jobs, err := intruder.Generate(input.Mode, len(markers), payloadSets)
	if err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_INTRUDER", err)
		return
	}
	results := make([]map[string]interface{}, len(jobs))
	var wg sync.WaitGroup
	var mu sync.Mutex
	for index := range jobs {
		wg.Add(1)
		go func(index int) {
			defer wg.Done()
			job := jobs[index]
			req := cloneRequest(input.BaseRequest)
			position := 0
			req.URL, position = intruder.ReplaceAt(req.URL, job.Values, position)
			for _, key := range sortedHeaderKeys(req.Headers) {
				req.Headers[key], position = intruder.ReplaceAt(req.Headers[key], job.Values, position)
			}
			req.Body, _ = intruder.ReplaceAt(req.Body, job.Values, position)
			result, execErr := s.execute(r, req)
			if execErr != nil {
				result = map[string]interface{}{"error": execErr.Error(), "payloads": job.Values}
			} else {
				result["payloads"] = job.Values
			}
			mu.Lock()
			results[index] = result
			mu.Unlock()
		}(index)
	}
	wg.Wait()
	writeJSON(w, http.StatusOK, map[string]interface{}{"results": results})
}

func requestPositions(input requestInput) []string {
	values := intruder.Positions(input.URL)
	keys := sortedHeaderKeys(input.Headers)
	for _, key := range keys {
		values = append(values, intruder.Positions(input.Headers[key])...)
	}
	values = append(values, intruder.Positions(input.Body)...)
	return values
}

func sortedHeaderKeys(headers map[string]string) []string {
	keys := make([]string, 0, len(headers))
	for key := range headers {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}

func cloneRequest(input requestInput) requestInput {
	headers := make(map[string]string, len(input.Headers))
	for key, value := range input.Headers {
		headers[key] = value
	}
	input.Headers = headers
	return input
}

func writeJSON(w http.ResponseWriter, status int, value interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func writeError(w http.ResponseWriter, status int, reason string, err error) {
	writeJSON(w, status, map[string]string{"error": err.Error(), "reason": reason})
}
