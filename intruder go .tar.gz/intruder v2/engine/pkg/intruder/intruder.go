package intruder

import (
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"net/url"
	"sort"
	"strings"
	"unicode/utf8"
)

type AttackMode string

const (
	Sniper       AttackMode = "sniper"
	BatteringRam AttackMode = "batteringRam"
	Pitchfork    AttackMode = "pitchfork"
	ClusterBomb  AttackMode = "clusterBomb"
)

type Request struct {
	Method  string            `json:"method"`
	URL     string            `json:"url"`
	Headers map[string]string `json:"headers"`
	Body    string            `json:"body"`
}

type Job struct {
	Values []string
}

type Transform struct {
	Operation string `json:"operation"`
	Value     string `json:"value"`
}

func TransformPayload(value string, transforms []Transform) (string, error) {
	for _, transform := range transforms {
		var err error
		switch transform.Operation {
		case "urlEncode":
			value = url.QueryEscape(value)
		case "urlDecode":
			value, err = url.QueryUnescape(value)
		case "base64Encode":
			value = base64.StdEncoding.EncodeToString([]byte(value))
		case "base64Decode":
			var data []byte
			data, err = base64.StdEncoding.DecodeString(value)
			value = string(data)
		case "base64UrlEncode":
			value = base64.RawURLEncoding.EncodeToString([]byte(value))
		case "base64UrlDecode":
			var data []byte
			data, err = base64.RawURLEncoding.DecodeString(value)
			value = string(data)
		case "htmlEntityEncode":
			value = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", "\"", "&quot;", "'", "&#39;").Replace(value)
		case "jsonEscape":
			value = strings.NewReplacer("\\", "\\\\", "\"", "\\\"", "\n", "\\n", "\r", "\\r", "\t", "\\t").Replace(value)
		case "unicodeEscape":
			var builder strings.Builder
			for _, character := range value {
				if character <= 0xffff {
					fmt.Fprintf(&builder, "\\u%04x", character)
				} else {
					builder.WriteString(fmt.Sprintf("\\u%04x", character))
				}
			}
			value = builder.String()
		case "hexEncode":
			value = hex.EncodeToString([]byte(value))
		case "hexDecode":
			var data []byte
			data, err = hex.DecodeString(value)
			value = string(data)
		case "whitespaceNormalize":
			value = strings.Join(strings.Fields(value), " ")
		case "trim":
			value = strings.TrimSpace(value)
		case "lowercase":
			value = strings.ToLower(value)
		case "uppercase":
			value = strings.ToUpper(value)
		case "prepend":
			value = transform.Value + value
		case "append":
			value += transform.Value
		default:
			return "", fmt.Errorf("unsupported payload transformation %q", transform.Operation)
		}
		if err != nil {
			return "", err
		}
	}
	if !utf8.ValidString(value) {
		return "", fmt.Errorf("transformed payload is not valid UTF-8")
	}
	return value, nil
}

func Positions(text string) []string {
	var positions []string
	for {
		start, end, value := nextMarker(text)
		if start < 0 {
			break
		}
		positions = append(positions, value)
		text = text[end:]
	}
	return positions
}

func Replace(text string, values []string) string {
	result, _ := ReplaceAt(text, values, 0)
	return result
}

func ReplaceAt(text string, values []string, offset int) (string, int) {
	var out strings.Builder
	position := offset
	for i := 0; i < len(text); {
		start, end, _ := nextMarker(text[i:])
		if start < 0 {
			out.WriteString(text[i:])
			break
		}
		start += i
		end += i
		out.WriteString(text[i:start])
		if position < len(values) {
			out.WriteString(values[position])
		}
		position++
		i = end
	}
	return out.String(), position
}

func nextMarker(text string) (int, int, string) {
	sectionStart := strings.Index(text, "§")
	sectionEnd := -1
	if sectionStart >= 0 {
		if end := strings.Index(text[sectionStart+len("§"):], "§"); end >= 0 {
			sectionEnd = sectionStart + len("§") + end + len("§")
		}
	}
	doubleStart := strings.Index(text, "{{")
	doubleEnd := -1
	if doubleStart >= 0 {
		if end := strings.Index(text[doubleStart+2:], "}}"); end >= 0 {
			doubleEnd = doubleStart + 2 + end + 2
		}
	}
	if sectionStart < 0 && doubleStart < 0 {
		return -1, -1, ""
	}
	if doubleStart >= 0 && (sectionStart < 0 || doubleStart < sectionStart) {
		return doubleStart, doubleEnd, text[doubleStart+2 : doubleEnd-2]
	}
	return sectionStart, sectionEnd, text[sectionStart+len("§") : sectionEnd-len("§")]
}

func Generate(mode AttackMode, positionCount int, payloadSets [][]string) ([]Job, error) {
	if positionCount == 0 || len(payloadSets) == 0 {
		return nil, fmt.Errorf("at least one marked position and payload list are required")
	}
	switch mode {
	case Sniper:
		var jobs []Job
		for position := 0; position < positionCount; position++ {
			for _, payload := range payloadSets[0] {
				values := make([]string, positionCount)
				for i := range values {
					values[i] = ""
				}
				values[position] = payload
				jobs = append(jobs, Job{Values: values})
			}
		}
		return jobs, nil
	case BatteringRam:
		return mapJobs(payloadSets[0], positionCount), nil
	case Pitchfork:
		n := len(payloadSets[0])
		for _, set := range payloadSets[1:] {
			if len(set) < n {
				n = len(set)
			}
		}
		jobs := make([]Job, 0, n)
		for i := 0; i < n; i++ {
			values := make([]string, positionCount)
			for p := range values {
				values[p] = payloadSets[min(p, len(payloadSets)-1)][i]
			}
			jobs = append(jobs, Job{Values: values})
		}
		return jobs, nil
	case ClusterBomb:
		var jobs []Job
		var walk func(int, []string)
		walk = func(index int, values []string) {
			if index == len(payloadSets) {
				for len(values) < positionCount {
					values = append(values, values[len(values)%len(values)])
				}
				jobs = append(jobs, Job{Values: append([]string(nil), values[:positionCount]...)})
				return
			}
			for _, payload := range payloadSets[index] {
				walk(index+1, append(values, payload))
			}
		}
		walk(0, nil)
		return jobs, nil
	default:
		return nil, fmt.Errorf("unsupported attack mode %q", mode)
	}
}

func mapJobs(payloads []string, count int) []Job {
	jobs := make([]Job, 0, len(payloads))
	for _, payload := range payloads {
		values := make([]string, count)
		for i := range values {
			values[i] = payload
		}
		jobs = append(jobs, Job{Values: values})
	}
	return jobs
}

func SortResults(results []map[string]interface{}) {
	sort.SliceStable(results, func(i, j int) bool {
		return fmt.Sprint(results[i]["status"]) < fmt.Sprint(results[j]["status"])
	})
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
