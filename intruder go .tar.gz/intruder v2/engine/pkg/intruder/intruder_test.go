package intruder

import "testing"

func TestGenerateModes(t *testing.T) {
	tests := []struct {
		name string
		mode AttackMode
		sets [][]string
		want int
	}{
		{"sniper", Sniper, [][]string{{"a", "b"}}, 4},
		{"battering ram", BatteringRam, [][]string{{"a", "b"}}, 2},
		{"pitchfork", Pitchfork, [][]string{{"a", "b"}, {"1", "2"}}, 2},
		{"cluster bomb", ClusterBomb, [][]string{{"a", "b"}, {"1", "2", "3"}}, 6},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			jobs, err := Generate(test.mode, 2, test.sets)
			if err != nil || len(jobs) != test.want {
				t.Fatalf("Generate() returned %d jobs, err=%v; want %d", len(jobs), err, test.want)
			}
		})
	}
}

func TestReplace(t *testing.T) {
	got := Replace("id=§one§&name=§two§", []string{"1", "alice"})
	if got != "id=1&name=alice" {
		t.Fatalf("Replace() = %q", got)
	}
}

func TestDoubleBraceMarkers(t *testing.T) {
	if got := Replace("q={{one}}&name=§two§", []string{"1", "alice"}); got != "q=1&name=alice" {
		t.Fatalf("Replace() = %q", got)
	}
}

func TestTransformPayload(t *testing.T) {
	got, err := TransformPayload("Hello world", []Transform{{Operation: "urlEncode"}})
	if err != nil || got != "Hello+world" {
		t.Fatalf("TransformPayload() = %q, err=%v", got, err)
	}
}
