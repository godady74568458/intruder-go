package passive

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"

	"intruder/engine/pkg/ca"

	"github.com/elazarl/goproxy"
)

type Event struct {
	Session        int64             `json:"session"`
	Timestamp      time.Time         `json:"timestamp"`
	Method         string            `json:"method"`
	URL            string            `json:"url"`
	RequestHeader  map[string]string `json:"request_headers"`
	RequestBody    string            `json:"request_body"`
	Status         int               `json:"status,omitempty"`
	ResponseHeader map[string]string `json:"response_headers,omitempty"`
	ResponseBody   string            `json:"response_body,omitempty"`
	Error          string            `json:"error,omitempty"`
}

type Store struct {
	mu     sync.RWMutex
	events []Event
}

func NewStore() *Store {
	return &Store{}
}

func (s *Store) Add(event Event) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.events = append(s.events, event)
}

func (s *Store) List() []Event {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if len(s.events) == 0 {
		return []Event{}
	}
	return append([]Event(nil), s.events...)
}

type Proxy struct {
	Store *Store
}

func NewProxy(store *Store) *Proxy {
	return &Proxy{Store: store}
}

func (p *Proxy) Handler() http.Handler {
	proxy := goproxy.NewProxyHttpServer()
	proxy.OnRequest().HandleConnect(goproxy.AlwaysMitm)
	proxy.OnRequest().DoFunc(p.captureRequest)
	proxy.OnResponse().DoFunc(p.captureResponse)

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !r.URL.IsAbs() && r.URL.Path == "/events" {
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(p.Store.List())
			return
		}
		proxy.ServeHTTP(w, r)
	})
}

func (p *Proxy) captureRequest(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
	body, err := readAndRestore(&r.Body)
	event := Event{
		Session:       ctx.Session,
		Timestamp:     time.Now().UTC(),
		Method:        r.Method,
		URL:           r.URL.String(),
		RequestHeader: flattenHeaders(r.Header),
		RequestBody:   string(body),
	}
	if err != nil {
		event.Error = err.Error()
	}
	ctx.UserData = &event
	return r, nil
}

func (p *Proxy) captureResponse(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
	event, ok := ctx.UserData.(*Event)
	if !ok {
		event = &Event{Session: ctx.Session, Timestamp: time.Now().UTC()}
	}
	if ctx.Error != nil {
		event.Error = ctx.Error.Error()
	}
	if resp != nil {
		body, err := readAndRestore(&resp.Body)
		event.Status = resp.StatusCode
		event.ResponseHeader = flattenHeaders(resp.Header)
		event.ResponseBody = string(body)
		if err != nil && event.Error == "" {
			event.Error = err.Error()
		}
	}
	p.Store.Add(*event)
	log.Printf("[PASSIVE %d] %s %s -> %d", event.Session, event.Method, event.URL, event.Status)
	return resp
}

func readAndRestore(body *io.ReadCloser) ([]byte, error) {
	if body == nil || *body == nil {
		return nil, nil
	}
	data, err := io.ReadAll(*body)
	_ = (*body).Close()
	*body = io.NopCloser(bytes.NewReader(data))
	return data, err
}

func flattenHeaders(headers http.Header) map[string]string {
	result := make(map[string]string, len(headers))
	for key, values := range headers {
		result[key] = joinHeaderValues(values)
	}
	return result
}

func joinHeaderValues(values []string) string {
	result := ""
	for index, value := range values {
		if index > 0 {
			result += ", "
		}
		result += value
	}
	return result
}

func ConfigureCA() error {
	certPath, keyPath := os.Getenv("CA_CERT"), os.Getenv("CA_KEY")
	if dir := os.Getenv("CA_DIR"); dir != "" {
		manager, err := ca.NewCAManager(dir)
		if err != nil {
			return err
		}
		certPath, keyPath = manager.CertPath, manager.KeyPath
	}
	if certPath == "" && keyPath == "" {
		return nil
	}
	if certPath == "" || keyPath == "" {
		return os.ErrInvalid
	}
	cert, err := tls.LoadX509KeyPair(filepath.Clean(certPath), filepath.Clean(keyPath))
	if err != nil {
		return err
	}
	goproxy.GoproxyCa = cert
	return nil
}
