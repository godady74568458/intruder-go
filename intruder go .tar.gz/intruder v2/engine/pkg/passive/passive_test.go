package passive

import (
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestReadAndRestorePreservesBody(t *testing.T) {
	body := io.NopCloser(strings.NewReader("0123456789"))
	captured, err := readAndRestore(&body)
	if err != nil {
		t.Fatalf("readAndRestore() error = %v", err)
	}
	if string(captured) != "0123456789" {
		t.Fatalf("captured body = %q, want original body", captured)
	}
	restored, err := io.ReadAll(body)
	if err != nil {
		t.Fatalf("reading restored body: %v", err)
	}
	if string(restored) != "0123456789" {
		t.Fatalf("restored body = %q, want original body", restored)
	}
}

func TestStoreKeepsMostRecentEvents(t *testing.T) {
	store := NewStore()
	for index := int64(1); index <= 3; index++ {
		store.Add(Event{Session: index})
	}
	events := store.List()
	if len(events) != 3 || events[0].Session != 1 || events[2].Session != 3 {
		t.Fatalf("stored events = %#v, want all sessions", events)
	}
}

func TestFlattenHeaders(t *testing.T) {
	headers := flattenHeaders(http.Header{"X-Test": {"one", "two"}})
	if headers["X-Test"] != "one, two" {
		t.Fatalf("flattened header = %q", headers["X-Test"])
	}
}
