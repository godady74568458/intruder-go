# Intruder Lab

Локальное веб-приложение для ручного анализа и повторной отправки HTTP-запросов
с Repeater и упрощённым Intruder.

В проекте намеренно **нет** Allowed Hosts, SSRF policy, режимов авторизации,
ограничений назначения, timeout policy, response-size policy или лимитов
ресурсов. Запросы передаются через Django в Go engine без таких проверок.

## Возможности

- тёмный Django UI на `http://localhost:8000`;
- Repeater для method, URL, query params, headers, cookies и body;
- выполнение запросов через Go engine;
- response status, time, size, headers и body;
- Pretty, Raw, Headers, Copy и Clear;
- `Ctrl+Enter` / `Cmd+Enter`;
- History в SQLite с загрузкой, удалением, поиском, сортировкой и Copy;
- Intruder modes:
  - Sniper;
  - Battering Ram;
  - Pitchfork;
  - Cluster Bomb;
- маркеры `§name§` и `{{name}}`;
- отдельные dictionaries по имени маркера или индексу;
- payload transformations: URL, Base64, HTML entities, JSON, Unicode, hex,
  trim, case, prepend и append;
- passive proxy на `127.0.0.1:8080` и локальный CA-код из `engine/pkg/ca`.

## Архитектура

```text
Browser :8000
   │
   ▼
Django web
   ├── HTML/JavaScript UI
   ├── SQLite history
   └── gateway
         │
         ▼
Go engine :8081
   ├── /health
   ├── /proxy/request
   └── /proxy/intruder
```

## Запуск

### Docker Compose

```bash
docker compose up --build
```

Адреса:

- UI: <http://localhost:8000>;
- engine health: <http://127.0.0.1:8081/health>;
- passive proxy: `127.0.0.1:8080`.

### Локально

```bash
cd engine
go run .
```

В другом терминале:

```bash
cd web
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 127.0.0.1:8000
```

Если engine находится не на стандартном адресе:

```bash
ENGINE_URL=http://127.0.0.1:8081 python manage.py runserver 127.0.0.1:8000
```

## Django API

| Method | Endpoint | Назначение |
|---|---|---|
| `GET` | `/` | UI |
| `POST` | `/api/execute` | Repeater gateway |
| `POST` | `/api/intruder` | Intruder gateway |
| `GET` | `/api/history` | History list |
| `DELETE` | `/api/history/<id>` | Удаление записи |

History поддерживает query-параметры:

```text
/api/history?q=search&sort=-timestamp
```

Поддерживаемые поля сортировки: `timestamp`, `method`, `status_code`,
`latency_ms`, включая вариант с префиксом `-`.

## Go API

### `GET /health`

```json
{"ok": true}
```

### `POST /proxy/request`

```json
{
  "method": "POST",
  "url": "http://localhost:3000/api",
  "headers": {"Content-Type": "application/json"},
  "body": "{\"name\":\"alice\"}"
}
```

Ответ:

```json
{
  "status": 200,
  "time": 18,
  "size": 12,
  "headers": {"Content-Type": "application/json"},
  "body": "{\"ok\":true}"
}
```

Engine не добавляет timeout, redirect policy или response-size restriction.
Redirect возвращается клиенту как исходный response.

### `POST /proxy/intruder`

```json
{
  "base_request": {
    "method": "GET",
    "url": "http://localhost:3000/?id=§value§",
    "headers": {},
    "body": ""
  },
  "mode": "sniper",
  "payloads": [["1", "2", "3"]],
  "dictionaries": {"value": ["one", "two"]},
  "transformations": [{"operation": "urlEncode"}]
}
```

`dictionaries` выбирает payload list по имени маркера или индексу. Если словарь
не найден, используется соответствующий список из `payloads`.

Jobs запускаются параллельно отдельными goroutines. В проекте нет UI/API для
concurrency, delay, rate limit или других ограничителей.

## История

История хранится в модели `TrafficRecord`:

```text
timestamp
method
url
request_headers
request_body
response_headers
response_body
status_code
latency_ms
response_size
```

## Тестирование

```bash
cd engine
go test ./...

cd ../web
python manage.py check
python manage.py test
```

Тесты покрывают генерацию Intruder modes, marker replacement, transformations,
passive capture и выдачу History.

## Структура

```text
.
├── docker-compose.yml
├── Prompt
├── README.md
├── engine/
│   ├── main.go
│   └── pkg/
│       ├── ca/
│       ├── intruder/
│       └── passive/
└── web/
    ├── manage.py
    ├── core/
    ├── lab/
    └── templates/lab/index.html
```
