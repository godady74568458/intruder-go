package intruder

import (
	"fmt"
	"sort"
	"strings"
)

type AttackMode string

const (
	Sniper       AttackMode = "sniper"
	BatteringRam AttackMode = "batteringRam"
	Pitchfork    AttackMode = "pitchfork"
	ClusterBomb  AttackMode = "clusterBomb"
)

type Request struct {
	Method  string            `json:"method"`
	URL     string            `json:"url"`
	Headers map[string]string `json:"headers"`
	Body    string            `json:"body"`
}

type Job struct {
	Values []string
}

func Positions(text string) []string {
	var positions []string
	for {
		start := strings.Index(text, "§")
		if start < 0 {
			break
		}
		end := strings.Index(text[start+len("§"):], "§")
		if end < 0 {
			break
		}
		end += start + len("§")
		positions = append(positions, text[start+len("§"):end])
		text = text[end+len("§"):]
	}
	return positions
}

func Replace(text string, values []string) string {
	var out strings.Builder
	for i := 0; i < len(text); {
		start := strings.Index(text[i:], "§")
		if start < 0 {
			out.WriteString(text[i:])
			break
		}
		start += i
		end := strings.Index(text[start+len("§"):], "§")
		if end < 0 {
			out.WriteString(text[i:])
			break
		}
		end += start + len("§")
		out.WriteString(text[i:start])
		position := len(Positions(text[:start]))
		if position < len(values) {
			out.WriteString(values[position])
		}
		i = end + len("§")
	}
	return out.String()
}

func Generate(mode AttackMode, positionCount int, payloadSets [][]string) ([]Job, error) {
	if positionCount == 0 || len(payloadSets) == 0 {
		return nil, fmt.Errorf("at least one marked position and payload list are required")
	}
	switch mode {
	case Sniper:
		var jobs []Job
		for position := 0; position < positionCount; position++ {
			for _, payload := range payloadSets[0] {
				values := make([]string, positionCount)
				for i := range values {
					values[i] = ""
				}
				values[position] = payload
				jobs = append(jobs, Job{Values: values})
			}
		}
		return jobs, nil
	case BatteringRam:
		return mapJobs(payloadSets[0], positionCount), nil
	case Pitchfork:
		n := len(payloadSets[0])
		for _, set := range payloadSets[1:] {
			if len(set) < n {
				n = len(set)
			}
		}
		jobs := make([]Job, 0, n)
		for i := 0; i < n; i++ {
			values := make([]string, positionCount)
			for p := range values {
				values[p] = payloadSets[min(p, len(payloadSets)-1)][i]
			}
			jobs = append(jobs, Job{Values: values})
		}
		return jobs, nil
	case ClusterBomb:
		var jobs []Job
		var walk func(int, []string)
		walk = func(index int, values []string) {
			if index == len(payloadSets) {
				for len(values) < positionCount {
					values = append(values, values[len(values)%len(values)])
				}
				jobs = append(jobs, Job{Values: append([]string(nil), values[:positionCount]...)})
				return
			}
			for _, payload := range payloadSets[index] {
				walk(index+1, append(values, payload))
			}
		}
		walk(0, nil)
		return jobs, nil
	default:
		return nil, fmt.Errorf("unsupported attack mode %q", mode)
	}
}

func mapJobs(payloads []string, count int) []Job {
	jobs := make([]Job, 0, len(payloads))
	for _, payload := range payloads {
		values := make([]string, count)
		for i := range values {
			values[i] = payload
		}
		jobs = append(jobs, Job{Values: values})
	}
	return jobs
}

func SortResults(results []map[string]interface{}) {
	sort.SliceStable(results, func(i, j int) bool {
		return fmt.Sprint(results[i]["status"]) < fmt.Sprint(results[j]["status"])
	})
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
