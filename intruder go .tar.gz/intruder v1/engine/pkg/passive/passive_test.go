package passive

import (
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestReadAndRestorePreservesBodyAndLimitsCapture(t *testing.T) {
	body := io.NopCloser(strings.NewReader("0123456789"))
	captured, err := readAndRestore(&body, 4)
	if err != nil {
		t.Fatalf("readAndRestore() error = %v", err)
	}
	if string(captured) != "0123" {
		t.Fatalf("captured body = %q, want %q", captured, "0123")
	}
	restored, err := io.ReadAll(body)
	if err != nil {
		t.Fatalf("reading restored body: %v", err)
	}
	if string(restored) != "0123456789" {
		t.Fatalf("restored body = %q, want original body", restored)
	}
}

func TestStoreKeepsMostRecentEvents(t *testing.T) {
	store := NewStore(2)
	for index := int64(1); index <= 3; index++ {
		store.Add(Event{Session: index})
	}
	events := store.List()
	if len(events) != 2 || events[0].Session != 2 || events[1].Session != 3 {
		t.Fatalf("stored events = %#v, want sessions 2 and 3", events)
	}
}

func TestFlattenHeaders(t *testing.T) {
	headers := flattenHeaders(http.Header{"X-Test": {"one", "two"}})
	if headers["X-Test"] != "one, two" {
		t.Fatalf("flattened header = %q", headers["X-Test"])
	}
}
