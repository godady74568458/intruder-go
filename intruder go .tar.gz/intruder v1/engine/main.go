package main

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"intruder/engine/pkg/intruder"
	"intruder/engine/pkg/passive"
)

type server struct{}

type requestInput struct {
	Method  string            `json:"method"`
	URL     string            `json:"url"`
	Headers map[string]string `json:"headers"`
	Body    string            `json:"body"`
}

type intruderInput struct {
	BaseRequest requestInput        `json:"base_request"`
	Mode        intruder.AttackMode `json:"mode"`
	Payloads    [][]string          `json:"payloads"`
}

func main() {
	if err := passive.ConfigureCA(); err != nil {
		log.Fatalf("configure passive proxy CA: %v", err)
	}

	s := &server{}
	mux := http.NewServeMux()
	mux.HandleFunc("/health", s.health)
	mux.HandleFunc("/proxy/request", s.request)
	mux.HandleFunc("/proxy/intruder", s.intruder)
	store := passive.NewStore(500)
	proxy := passive.NewProxy(store)

	go func() {
		log.Println("passive MITM proxy listening on 127.0.0.1:8080")
		if err := http.ListenAndServe("127.0.0.1:8080", proxy.Handler()); err != nil {
			log.Fatalf("passive proxy: %v", err)
		}
	}()

	log.Println("engine listening on 127.0.0.1:8081")
	log.Fatal(http.ListenAndServe("127.0.0.1:8081", mux))
}

func (s *server) health(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]interface{}{"ok": true})
}

func (s *server) request(w http.ResponseWriter, r *http.Request) {
	var input requestInput
	if err := json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(&input); err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_JSON", err)
		return
	}
	result, err := s.execute(r, input)
	if err != nil {
		writeError(w, http.StatusBadGateway, "REQUEST_FAILED", err)
		return
	}
	writeJSON(w, http.StatusOK, result)
}

func (s *server) execute(r *http.Request, input requestInput) (map[string]interface{}, error) {
	method := input.Method
	if method == "" {
		method = http.MethodGet
	}
	req, err := http.NewRequestWithContext(r.Context(), method, input.URL, strings.NewReader(input.Body))
	if err != nil {
		return nil, err
	}
	for key, value := range input.Headers {
		req.Header.Set(key, value)
	}
	start := time.Now()
	resp, err := (&http.Client{CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}).Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	headers := map[string]string{}
	for key, values := range resp.Header {
		headers[key] = strings.Join(values, ", ")
	}
	return map[string]interface{}{"status": resp.StatusCode, "time": time.Since(start).Milliseconds(), "size": len(body), "headers": headers, "body": string(body)}, nil
}

func (s *server) intruder(w http.ResponseWriter, r *http.Request) {
	var input intruderInput
	if err := json.NewDecoder(io.LimitReader(r.Body, 4<<20)).Decode(&input); err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_JSON", err)
		return
	}
	markers := intruder.Positions(input.BaseRequest.URL + input.BaseRequest.Body)
	jobs, err := intruder.Generate(input.Mode, len(markers), input.Payloads)
	if err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_INTRUDER", err)
		return
	}
	results := make([]map[string]interface{}, len(jobs))
	var wg sync.WaitGroup
	var mu sync.Mutex
	for index := range jobs {
		wg.Add(1)
		go func(index int) {
			defer wg.Done()
			job := jobs[index]
			req := input.BaseRequest
			req.URL = intruder.Replace(req.URL, job.Values)
			req.Body = intruder.Replace(req.Body, job.Values)
			for key, value := range req.Headers {
				req.Headers[key] = intruder.Replace(value, job.Values)
			}
			result, execErr := s.execute(r, req)
			if execErr != nil {
				result = map[string]interface{}{"error": execErr.Error(), "payloads": job.Values}
			} else {
				result["payloads"] = job.Values
			}
			mu.Lock()
			results[index] = result
			mu.Unlock()
		}(index)
	}
	wg.Wait()
	writeJSON(w, http.StatusOK, map[string]interface{}{"results": results})
}

func writeJSON(w http.ResponseWriter, status int, value interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func writeError(w http.ResponseWriter, status int, reason string, err error) {
	writeJSON(w, status, map[string]string{"error": err.Error(), "reason": reason})
}
