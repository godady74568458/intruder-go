from django.db import models

class TrafficRecord(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    method = models.CharField(max_length=10)
    url = models.URLField(max_length=2048)
    request_headers = models.JSONField(default=dict)
    request_body = models.TextField(null=True, blank=True)
    response_headers = models.JSONField(default=dict)
    response_body = models.TextField(null=True, blank=True)
    status_code = models.IntegerField(null=True, blank=True)
    latency_ms = models.IntegerField(null=True, blank=True)

class IntruderAttack(models.Model):
    TYPE_CHOICES = [
        ('sniper', 'Sniper'),
        ('batteringRam', 'Battering Ram'),
        ('pitchfork', 'Pitchfork'),
        ('clusterBomb', 'Cluster Bomb'),
    ]
    attack_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    base_request = models.JSONField()
    payloads = models.JSONField()
    transformations = models.JSONField(default=list)
    status = models.CharField(max_length=20, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

class AuditLog(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    action = models.CharField(max_length=50)
    target = models.CharField(max_length=255)
    reason = models.TextField()
    policy_mode = models.CharField(max_length=20)
