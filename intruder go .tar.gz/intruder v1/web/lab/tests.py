from django.test import Client, TestCase

from .models import TrafficRecord


class HistoryAndSettingsTests(TestCase):
    def setUp(self):
        self.client = Client()

    def test_history_returns_saved_records(self):
        record = TrafficRecord.objects.create(method="GET", url="http://localhost:3000", status_code=200)
        response = self.client.get("/api/history")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["items"][0]["id"], record.id)
