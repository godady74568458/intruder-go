import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from .models import TrafficRecord

ENGINE_URL = os.environ.get("ENGINE_URL", "http://127.0.0.1:8081")


def index(request):
    return render(request, "lab/index.html")


def history(request):
    records = TrafficRecord.objects.order_by("-timestamp")[:200]
    return JsonResponse({"items": [
        {"id": item.id, "timestamp": item.timestamp, "method": item.method, "url": item.url,
         "request_headers": item.request_headers, "request_body": item.request_body or "",
         "status": item.status_code, "time": item.latency_ms, "response_headers": item.response_headers,
         "response_body": item.response_body or ""}
        for item in records
    ]})


@csrf_exempt
def history_detail(request, record_id=None):
    if request.method == "DELETE":
        TrafficRecord.objects.filter(id=record_id).delete()
        return JsonResponse({"ok": True})
    return JsonResponse({"error": "method not allowed"}, status=405)


def call_engine(path, payload):
    request = Request(
        f"{ENGINE_URL}{path}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request) as response:
            return response.status, json.loads(response.read())
    except HTTPError as error:
        try:
            return error.code, json.loads(error.read())
        except json.JSONDecodeError:
            return error.code, {"error": error.reason}
    except URLError as error:
        return 502, {"error": f"engine unavailable: {error.reason}", "reason": "ENGINE_UNAVAILABLE"}


@csrf_exempt
def execute(request):
    if request.method != "POST":
        return JsonResponse({"error": "method not allowed"}, status=405)
    try:
        payload = json.loads(request.body)
        status, result = call_engine("/proxy/request", payload)
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"error": "invalid JSON"}, status=400)
    if status == 200:
        TrafficRecord.objects.create(
            method=payload.get("method", "GET"),
            url=payload.get("url", ""),
            request_headers=payload.get("headers", {}),
            request_body=payload.get("body", ""),
            response_headers=result.get("headers", {}),
            response_body=result.get("body", ""),
            status_code=result.get("status"),
            latency_ms=result.get("time"),
        )
    return JsonResponse(result, status=status)


@csrf_exempt
def intruder(request):
    if request.method != "POST":
        return JsonResponse({"error": "method not allowed"}, status=405)
    try:
        status, result = call_engine("/proxy/intruder", json.loads(request.body))
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"error": "invalid JSON"}, status=400)
    return JsonResponse(result, status=status)
