# Intruder Lab

Локальное веб-приложение для ручного анализа и повторной отправки HTTP-запросов
с Repeater и упрощённым Intruder.

В проекте намеренно **нет** Allowed Hosts, SSRF policy, режимов авторизации,
ограничений назначения, timeout policy, response-size policy или лимитов
ресурсов. Запросы передаются через Django в Go engine без таких проверок.

## Возможности

- тёмный Django UI на `http://localhost:8000`;
- Repeater для method, URL, query params, headers, cookies и body;
- выполнение запросов через Go engine;
- response status, time, size, headers и body;
- Pretty, Raw, Headers, Copy и Clear;
- `Ctrl+Enter` / `Cmd+Enter`;
- History в SQLite с загрузкой, удалением, поиском, сортировкой и Copy;
- Intruder modes:
  - Sniper;
  - Battering Ram;
  - Pitchfork;
  - Cluster Bomb;
- маркеры `§name§` и `{{name}}`;
- отдельные dictionaries по имени маркера или индексу;
- payload transformations: URL, Base64, HTML entities, JSON, Unicode, hex,
  trim, case, prepend и append;
- passive MITM proxy на `127.0.0.1:8080` с захватом всех hostnames, без фильтра
  только по Google, и локальный CA-код из `engine/pkg/ca`;
- Traffic получает события через SSE: запрос виден сразу после поступления в
  proxy, а response/status/latency дополняются без ручного Refresh;
- Traffic сортируется по времени, host и latency, а любой захваченный запрос
  можно загрузить в Repeater или Intruder.

## Архитектура

```text
Browser :8000
   │
   ▼
Django web
   ├── HTML/JavaScript UI
   ├── SQLite history
   └── gateway
         │
         ▼
Go engine :8081
   ├── /health
   ├── /proxy/request
   ├── /proxy/intruder
   ├── /events
   └── /events/stream
```

## Запуск

### Docker Compose

```bash
docker compose up --build
```

Адреса:

- UI: <http://localhost:8000>;
- engine health: <http://127.0.0.1:8081/health>;
- passive proxy: `127.0.0.1:8080` (в Docker engine слушает на `0.0.0.0` внутри
  контейнера, чтобы опубликованный порт принимал трафик).

### Локально

```bash
cd engine
go run .
```

В другом терминале:

```bash
cd web
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 127.0.0.1:8000
```

Если engine находится не на стандартном адресе:

```bash
ENGINE_URL=http://127.0.0.1:8081 python manage.py runserver 127.0.0.1:8000
```

## Django API

| Method | Endpoint | Назначение |
|---|---|---|
| `GET` | `/` | UI |
| `POST` | `/api/execute` | Repeater gateway |
| `POST` | `/api/intruder` | Intruder gateway |
| `GET` | `/api/history` | History list |
| `DELETE` | `/api/history/<id>` | Удаление записи |
| `GET` | `/api/traffic` | Passive proxy events snapshot |
| `GET` | `/api/traffic/stream` | Live passive proxy events (SSE) |

History поддерживает query-параметры:

```text
/api/history?q=search&sort=-timestamp
```

Поддерживаемые поля сортировки: `timestamp`, `method`, `status_code`,
`latency_ms`, включая вариант с префиксом `-`.

## Go API

### `GET /health`

```json
{"ok": true}
```

### `POST /proxy/request`

```json
{
  "method": "POST",
  "url": "http://localhost:3000/api",
  "headers": {"Content-Type": "application/json"},
  "body": "{\"name\":\"alice\"}"
}
```

Ответ:

```json
{
  "status": 200,
  "time": 18,
  "size": 12,
  "headers": {"Content-Type": "application/json"},
  "body": "{\"ok\":true}"
}
```

Engine не добавляет timeout, redirect policy или response-size restriction.
Redirect возвращается клиенту как исходный response.

### `POST /proxy/intruder`

```json
{
  "base_request": {
    "method": "GET",
    "url": "http://localhost:3000/?id=§value§",
    "headers": {},
    "body": ""
  },
  "mode": "sniper",
  "payloads": [["1", "2", "3"]],
  "dictionaries": {"value": ["one", "two"]},
  "transformations": [{"operation": "urlEncode"}]
}
```

`dictionaries` выбирает payload list по имени маркера или индексу. Если словарь
не найден, используется соответствующий список из `payloads`.

Jobs запускаются параллельно отдельными goroutines. В проекте нет UI/API для
concurrency, delay, rate limit или других ограничителей.

## История

История хранится в модели `TrafficRecord`:

```text
timestamp
method
url
request_headers
request_body
response_headers
response_body
status_code
latency_ms
response_size
```

## Тестирование

```bash
cd engine
go test ./...

cd ../web
python manage.py check
python manage.py test
```

Тесты покрывают генерацию Intruder modes, marker replacement, transformations,
passive capture и выдачу History.

## QA-прогон OWASP Juice Shop

Проверка выполнялась на локальной учебной цели:

```text
http://127.0.0.1:3000
```

Приложение Intruder Lab использовалось как основной клиент: запросы проходили
через Repeater, Intruder и passive proxy. Внешние цели и production-системы не
использовались.

### Проверенная матрица

| Область | Проверка | Результат |
|---|---|---|
| Engine | `GET /health` | PASS |
| Repeater | GET, POST, PUT, JSON, Authorization | PASS |
| Intruder | Pitchfork с двумя payload-списками | PASS |
| Passive proxy | Host, URL, method, status, body, latency | PASS |
| Traffic SSE | Событие появляется без ручного Refresh | PASS |
| Traffic UI | Сортировка по времени, host и latency | PASS |
| Transfer | Захват запроса в Repeater и Intruder | PASS |
| Django | `manage.py check` | PASS |
| Django | `manage.py test` | PASS |
| Go | `go test ./...` | PASS |

### Достигнутый результат

В локальной Juice Shop автоматически и вручную через приложение подтверждено
40 из 116 достижений. В прогон вошли authentication, registration, FTP/direct
access, product API, feedback/CAPTCHA, metrics, exposed credentials,
tampering, backup/null-byte и несколько easter egg challenges. Точный список
зависит от версии Juice Shop и сохраняется в локальном состоянии цели.

Не запускались намеренно опасные сценарии, которые могут остановить процесс,
создать длительную нагрузку или обратиться к внешней инфраструктуре:
RCE/DoS, XXE DoS, SSRF на внешние адреса, memory bomb и массовая автоматическая
модификация данных.

### Исправление, найденное во время QA

SSE gateway в Django читал поток блоками по 4096 байт. Из-за этого небольшое
событие Traffic могло не попасть в браузер до заполнения буфера. Чтение
переведено на строки SSE, после чего real-time проверка через proxy стала
проходить без задержки.

## Наблюдения по результатам QA

1. **Passive traffic capture.** Захваченные события сейчас хранятся в памяти
   engine и очищаются при его перезапуске.
2. **SSE-подключение.** При обрыве соединения браузер переподключается, но
   поток не использует `Last-Event-ID`, поэтому события, появившиеся во время
   разрыва, могут не попасть в текущий список.
3. **Содержимое трафика.** Заголовки и body отображаются в исходном виде;
   приложение не выполняет автоматическое маскирование секретов.
4. **Intruder UX.** Для длительной атаки нет отдельного progress bar,
   pause/resume и cancel в интерфейсе.
5. **Сравнение ответов.** Сейчас результаты Intruder выводятся как JSON без
   встроенного diff между response.
6. **Тестовое покрытие.** Полезно дополнить API-тестами `/api/traffic/stream`,
   normalize query/cookies, Intruder gateway и сортировки host/time.

## Предлагаемые новые функции

- **Request composer:** редактирование сырого HTTP-запроса, автоматическое
  выделение query/form/JSON параметров и быстрый перенос выбранного параметра
  в Intruder.
- **Intruder control panel:** progress, pause/resume/cancel, concurrency,
  delay и экспорт результатов в JSON/CSV.
- **Traffic filters:** live-фильтры по host, path, method, status, MIME,
  размеру, latency и тексту body; pin/freeze текущего списка.
- **Replay workflow:** кнопки `Send again`, `Send to Intruder`, `Duplicate`,
  сравнение двух response и diff headers/body.
- **Secrets and privacy:** опциональное маскирование секретов по умолчанию,
  локальное шифрование истории и кнопка очистки всех захваченных данных.
- **QA harness:** встроенный набор безопасных smoke targets и отчёт с числом
  запросов, ошибками, latency percentiles и покрытыми сценариями.

## Структура

```text
.
├── docker-compose.yml
├── Prompt
├── README.md
├── engine/
│   ├── main.go
│   └── pkg/
│       ├── ca/
│       ├── intruder/
│       └── passive/
└── web/
    ├── manage.py
    ├── core/
    ├── lab/
    └── templates/lab/index.html
```
