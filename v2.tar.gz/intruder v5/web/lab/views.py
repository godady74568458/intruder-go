import json
import os
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.http import JsonResponse, StreamingHttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from .models import TrafficRecord

ENGINE_URL = os.environ.get("ENGINE_URL", "http://127.0.0.1:8081")


def index(request):
    return render(request, "lab/index.html")


def history(request):
    records = TrafficRecord.objects.order_by("-timestamp")
    query = request.GET.get("q", "").strip()
    if query:
        records = records.filter(url__icontains=query)
    sort = request.GET.get("sort", "-timestamp")
    if sort in {"timestamp", "-timestamp", "method", "-method", "status_code", "-status_code", "latency_ms", "-latency_ms"}:
        records = records.order_by(sort)
    records = records[:200]
    return JsonResponse({"items": [
        {"id": item.id, "timestamp": item.timestamp, "method": item.method, "url": item.url,
         "request_headers": item.request_headers, "request_body": item.request_body or "",
         "status": item.status_code, "time": item.latency_ms, "response_headers": item.response_headers,
         "response_body": item.response_body or "", "response_size": item.response_size}
        for item in records
    ]})


@csrf_exempt
def history_detail(request, record_id=None):
    if request.method == "DELETE":
        TrafficRecord.objects.filter(id=record_id).delete()
        return JsonResponse({"ok": True})
    return JsonResponse({"error": "method not allowed"}, status=405)


def call_engine(path, payload):
    request = Request(
        f"{ENGINE_URL}{path}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request) as response:
            return response.status, json.loads(response.read())
    except HTTPError as error:
        try:
            return error.code, json.loads(error.read())
        except json.JSONDecodeError:
            return error.code, {"error": error.reason}
    except URLError as error:
        return 502, {"error": f"engine unavailable: {error.reason}", "reason": "ENGINE_UNAVAILABLE"}


def call_engine_get(path):
    try:
        with urlopen(f"{ENGINE_URL}{path}") as response:
            return response.status, json.loads(response.read())
    except HTTPError as error:
        return error.code, {"error": error.reason}
    except URLError as error:
        return 502, {"error": f"engine unavailable: {error.reason}", "reason": "ENGINE_UNAVAILABLE"}


def traffic(request):
    if request.method != "GET":
        return JsonResponse({"error": "method not allowed"}, status=405)
    status, result = call_engine_get("/events")
    return JsonResponse(result, status=status, safe=isinstance(result, dict))


def traffic_stream(request):
    if request.method != "GET":
        return JsonResponse({"error": "method not allowed"}, status=405)
    try:
        response = urlopen(f"{ENGINE_URL}/events/stream")
    except URLError as error:
        return JsonResponse({"error": f"engine unavailable: {error.reason}", "reason": "ENGINE_UNAVAILABLE"}, status=502)

    def stream():
        try:
            while True:
                chunk = response.readline()
                if not chunk:
                    break
                yield chunk
        finally:
            response.close()

    result = StreamingHttpResponse(stream(), content_type="text/event-stream")
    result["Cache-Control"] = "no-cache"
    result["X-Accel-Buffering"] = "no"
    return result


def normalize_payload(payload):
    payload = dict(payload)
    split = urlsplit(payload.get("url", ""))
    query = payload.pop("query", None)
    if isinstance(query, dict):
        merged = dict(parse_qsl(split.query, keep_blank_values=True))
        merged.update({str(key): str(value) for key, value in query.items()})
        payload["url"] = urlunsplit((split.scheme, split.netloc, split.path, urlencode(merged), split.fragment))
    cookies = payload.pop("cookies", None)
    if isinstance(cookies, dict):
        headers = dict(payload.get("headers") or {})
        headers["Cookie"] = "; ".join(f"{key}={value}" for key, value in cookies.items())
        payload["headers"] = headers
    return payload


@csrf_exempt
def execute(request):
    if request.method != "POST":
        return JsonResponse({"error": "method not allowed"}, status=405)
    try:
        payload = normalize_payload(json.loads(request.body))
        status, result = call_engine("/proxy/request", payload)
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"error": "invalid JSON"}, status=400)
    if status == 200:
        TrafficRecord.objects.create(
            method=payload.get("method", "GET"),
            url=payload.get("url", ""),
            request_headers=payload.get("headers", {}),
            request_body=payload.get("body", ""),
            response_headers=result.get("headers", {}),
            response_body=result.get("body", ""),
            status_code=result.get("status"),
            latency_ms=result.get("time"),
            response_size=result.get("size"),
        )
    return JsonResponse(result, status=status)


@csrf_exempt
def intruder(request):
    if request.method != "POST":
        return JsonResponse({"error": "method not allowed"}, status=405)
    try:
        payload = json.loads(request.body)
        payload["base_request"] = normalize_payload(payload.get("base_request", {}))
        status, result = call_engine("/proxy/intruder", payload)
    except (json.JSONDecodeError, TypeError):
        return JsonResponse({"error": "invalid JSON"}, status=400)
    return JsonResponse(result, status=status)
