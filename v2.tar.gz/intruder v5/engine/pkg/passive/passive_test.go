package passive

import (
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestReadAndRestorePreservesBody(t *testing.T) {
	body := io.NopCloser(strings.NewReader("0123456789"))
	captured, err := readAndRestore(&body)
	if err != nil {
		t.Fatalf("readAndRestore() error = %v", err)
	}
	if string(captured) != "0123456789" {
		t.Fatalf("captured body = %q, want original body", captured)
	}
	restored, err := io.ReadAll(body)
	if err != nil {
		t.Fatalf("reading restored body: %v", err)
	}
	if string(restored) != "0123456789" {
		t.Fatalf("restored body = %q, want original body", restored)
	}
}

func TestStoreKeepsMostRecentEvents(t *testing.T) {
	store := NewStore()
	for index := int64(1); index <= 3; index++ {
		store.Add(Event{Session: index})
	}
	events := store.List()
	if len(events) != 3 || events[0].Session != 1 || events[2].Session != 3 {
		t.Fatalf("stored events = %#v, want all sessions", events)
	}
}

func TestStorePublishesRequestAndResponseUpdates(t *testing.T) {
	store := NewStore()
	events, unsubscribe := store.Subscribe()
	defer unsubscribe()

	id := store.Add(Event{Method: "GET", URL: "https://example.test/path"})
	requestEvent := <-events
	if requestEvent.ID != id || requestEvent.URL == "" || requestEvent.Status != 0 {
		t.Fatalf("request event = %#v", requestEvent)
	}

	store.Update(id, func(event *Event) {
		event.Status = http.StatusNoContent
		event.Latency = 12
	})
	responseEvent := <-events
	if responseEvent.ID != id || responseEvent.Status != http.StatusNoContent || responseEvent.Latency != 12 {
		t.Fatalf("response event = %#v", responseEvent)
	}
}

func TestFlattenHeaders(t *testing.T) {
	headers := flattenHeaders(http.Header{"X-Test": {"one", "two"}})
	if headers["X-Test"] != "one, two" {
		t.Fatalf("flattened header = %q", headers["X-Test"])
	}
}
