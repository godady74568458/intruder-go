package passive

import (
	"bytes"
	"crypto/tls"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sync"
	"time"

	"intruder/engine/pkg/ca"

	"github.com/elazarl/goproxy"
)

type Event struct {
	ID             uint64            `json:"id"`
	Session        int64             `json:"session"`
	Timestamp      time.Time         `json:"timestamp"`
	Method         string            `json:"method"`
	URL            string            `json:"url"`
	Host           string            `json:"host"`
	RequestHeader  map[string]string `json:"request_headers"`
	RequestBody    string            `json:"request_body"`
	Status         int               `json:"status,omitempty"`
	ResponseHeader map[string]string `json:"response_headers,omitempty"`
	ResponseBody   string            `json:"response_body,omitempty"`
	ResponseSize   int               `json:"response_size,omitempty"`
	Latency        int64             `json:"latency_ms,omitempty"`
	Error          string            `json:"error,omitempty"`
}

type Store struct {
	mu          sync.RWMutex
	events      []Event
	subscribers map[chan Event]struct{}
	nextID      uint64
}

func NewStore() *Store {
	return &Store{subscribers: make(map[chan Event]struct{})}
}

func (s *Store) Add(event Event) uint64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.nextID++
	event.ID = s.nextID
	s.events = append(s.events, event)
	s.broadcastLocked(event)
	return event.ID
}

func (s *Store) List() []Event {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if len(s.events) == 0 {
		return []Event{}
	}
	return append([]Event(nil), s.events...)
}

func (s *Store) Update(id uint64, update func(*Event)) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for index := range s.events {
		if s.events[index].ID == id {
			update(&s.events[index])
			s.broadcastLocked(s.events[index])
			return
		}
	}
}

func (s *Store) Subscribe() (<-chan Event, func()) {
	channel := make(chan Event, 16)
	s.mu.Lock()
	s.subscribers[channel] = struct{}{}
	s.mu.Unlock()
	return channel, func() {
		s.mu.Lock()
		if _, ok := s.subscribers[channel]; ok {
			delete(s.subscribers, channel)
			close(channel)
		}
		s.mu.Unlock()
	}
}

func (s *Store) broadcastLocked(event Event) {
	for channel := range s.subscribers {
		select {
		case channel <- event:
		default:
			// A slow UI must not block proxy traffic.
		}
	}
}

type Proxy struct {
	Store *Store
}

func NewProxy(store *Store) *Proxy {
	return &Proxy{Store: store}
}

func (p *Proxy) Handler() http.Handler {
	proxy := goproxy.NewProxyHttpServer()
	proxy.OnRequest().HandleConnect(goproxy.AlwaysMitm)
	proxy.OnRequest().DoFunc(p.captureRequest)
	proxy.OnResponse().DoFunc(p.captureResponse)

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		proxy.ServeHTTP(w, r)
	})
}

func (p *Proxy) captureRequest(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
	body, err := readAndRestore(&r.Body)
	event := Event{
		Session:       ctx.Session,
		Timestamp:     time.Now().UTC(),
		Method:        r.Method,
		URL:           r.URL.String(),
		Host:          requestHost(r),
		RequestHeader: flattenHeaders(r.Header),
		RequestBody:   string(body),
	}
	if err != nil {
		event.Error = err.Error()
	}
	eventID := p.Store.Add(event)
	ctx.UserData = &captureState{eventID: eventID, started: time.Now()}
	return r, nil
}

func (p *Proxy) captureResponse(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
	state, ok := ctx.UserData.(*captureState)
	if !ok {
		state = &captureState{eventID: p.Store.Add(Event{Session: ctx.Session, Timestamp: time.Now().UTC()})}
	}
	var eventError string
	if ctx.Error != nil {
		eventError = ctx.Error.Error()
	}
	var status int
	var responseHeaders map[string]string
	var responseBody string
	var responseSize int
	if resp != nil {
		body, err := readAndRestore(&resp.Body)
		status = resp.StatusCode
		responseHeaders = flattenHeaders(resp.Header)
		responseBody = string(body)
		responseSize = len(body)
		if err != nil && eventError == "" {
			eventError = err.Error()
		}
	}
	latency := time.Since(state.started).Milliseconds()
	p.Store.Update(state.eventID, func(event *Event) {
		event.Status = status
		event.ResponseHeader = responseHeaders
		event.ResponseBody = responseBody
		event.ResponseSize = responseSize
		event.Latency = latency
		event.Error = eventError
	})
	log.Printf("[PASSIVE %d] request completed in %dms -> %d", state.eventID, latency, status)
	return resp
}

type captureState struct {
	eventID uint64
	started time.Time
}

func requestHost(r *http.Request) string {
	if r.URL != nil && r.URL.Host != "" {
		if parsed, err := url.Parse(r.URL.String()); err == nil && parsed.Host != "" {
			return parsed.Host
		}
	}
	return r.Host
}

func readAndRestore(body *io.ReadCloser) ([]byte, error) {
	if body == nil || *body == nil {
		return nil, nil
	}
	data, err := io.ReadAll(*body)
	_ = (*body).Close()
	*body = io.NopCloser(bytes.NewReader(data))
	return data, err
}

func flattenHeaders(headers http.Header) map[string]string {
	result := make(map[string]string, len(headers))
	for key, values := range headers {
		result[key] = joinHeaderValues(values)
	}
	return result
}

func joinHeaderValues(values []string) string {
	result := ""
	for index, value := range values {
		if index > 0 {
			result += ", "
		}
		result += value
	}
	return result
}

func ConfigureCA() error {
	certPath, keyPath := os.Getenv("CA_CERT"), os.Getenv("CA_KEY")
	if dir := os.Getenv("CA_DIR"); dir != "" {
		manager, err := ca.NewCAManager(dir)
		if err != nil {
			return err
		}
		certPath, keyPath = manager.CertPath, manager.KeyPath
	}
	if certPath == "" && keyPath == "" {
		return nil
	}
	if certPath == "" || keyPath == "" {
		return os.ErrInvalid
	}
	cert, err := tls.LoadX509KeyPair(filepath.Clean(certPath), filepath.Clean(keyPath))
	if err != nil {
		return err
	}
	goproxy.GoproxyCa = cert
	return nil
}
